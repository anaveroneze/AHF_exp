FILEPATH=/home/ana/Downloads/AHF_exp/RunningTests/Ascii
for x in `ls $FILEPATH`
do 
	FILENAME=$(ls $FILEPATH/$x | grep -E '.ascii|.txt|snapshot')
	FILESIZE=$(stat -c '%s' $FILEPATH/$x/$FILENAME)
	cd $FILEPATH/$x 
	/home/ana/Downloads/ahf-v1.0-091/bin/AHF-v1.0-091 $FILEPATH/$x/AHF.input
	TIME=$(cd $FILEPATH/$x | grep 'total time' *.log)
	cd ..
	echo "-Arquivo: $FILENAME Tamanho: $FILESIZE Execuções: 1 Tempo Exec: $TIME"
done > RunningTimes

